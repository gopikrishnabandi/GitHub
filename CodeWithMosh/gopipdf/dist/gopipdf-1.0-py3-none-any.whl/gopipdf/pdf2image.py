print('hi')

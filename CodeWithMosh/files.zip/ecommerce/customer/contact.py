def phonenumbers():
    print('Printing contact details of customers')

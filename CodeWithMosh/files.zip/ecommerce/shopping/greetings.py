def welcomegreeting():
    print('welcome to our website')
